# leaflet-parser

A React component library for parsing and rendering `pub.leaflet.pages.linearDocument` objects from Leaflet.

## Features

- 📖 **Display Mode**: Render Linear Documents as read-only content (server-compatible)
- ✏️ **Editable Mode**: Interactive editing with `onChange` callback for real-time updates
- ⚡ **Next.js Server Component Compatible**: No hydration errors - works seamlessly with RSC
- 🔒 **Type Safe**: End-to-end TypeScript support with auto-generated types from lexicons
- 🎨 **Rich Text**: Full support for facets (bold, italic, code, links, mentions, etc.)
- 📦 **Block Types**: Headers, text, blockquotes, code, lists (with nesting), images, and more

## Quick Start

### Installation

```bash
bun install
```

### Usage

```tsx
import { LinearDocument, EditableLinearDocument } from 'leaflet-parser';

// Display mode (read-only)
<LinearDocument 
  document={doc} 
  resolveBlobRef={(ref) => `https://your-cdn.com/${ref.ref.$link}`}
/>

// Editable mode
<EditableLinearDocument 
  document={doc}
  onChange={setDoc}
  resolveBlobRef={(ref) => `https://your-cdn.com/${ref.ref.$link}`}
/>
```

## Development

Start the development server with demo app:

```bash
bun dev
```

The demo app will be available at `http://localhost:3000` and showcases both display and editable modes.

Build for production:

```bash
bun run build
```

Run production build:

```bash
bun start
```

## Lexicon Types

This library uses ATProtocol lexicons to define document schemas. Types are auto-generated from lexicon JSON files.

Generate TypeScript types from lexicons:

```bash
bun run gen:lex-api
```

This reads lexicon files from `./lexicons/` and generates TypeScript types in `./lex-api/`.

## Supported Block Types

The library currently supports the following block types:

| Block Type | Display | Editable | Description |
|------------|---------|----------|-------------|
| `text` | ✅ | ✅ | Standard text block with rich text facets |
| `header` | ✅ | ✅ | Headings (H1-H6) |
| `blockquote` | ✅ | ✅ | Block quotes |
| `code` | ✅ | ✅ | Code blocks with language syntax |
| `unorderedList` | ✅ | ✅ | Bullet lists with nested support |
| `image` | ✅ | ✅ | Images with alt text (editable in edit mode) |
| `horizontalRule` | ✅ | N/A | Horizontal divider |

### Facet Support

All text-based blocks support the following facets:

- **Bold** (`pub.leaflet.richtext.facet#bold`)
- **Italic** (`pub.leaflet.richtext.facet#italic`)
- **Code** (`pub.leaflet.richtext.facet#code`)
- **Underline** (`pub.leaflet.richtext.facet#underline`)
- **Strikethrough** (`pub.leaflet.richtext.facet#strikethrough`)
- **Highlight** (`pub.leaflet.richtext.facet#highlight`)
- **Links** (`pub.leaflet.richtext.facet#link`)
- **Mentions** (DID and @ mentions)

## Architecture

### Core Components

- **`LinearDocument`** - Server-compatible display component
- **`EditableLinearDocument`** - Client-side editable component (uses `"use client"`)
- **`BlockRenderer`** - Routes blocks to appropriate display components
- **`EditableBlockRenderer`** - Routes blocks to appropriate editable components

### Utilities

- **`UnicodeString`** - Handles UTF-8 ↔ UTF-16 byte offset conversion for facets
- **`RichText`** - Iterates through text segments with applied facets
- **`adjustFacetsForEdit`** - Updates facet byte offsets when text changes
- **Type guards** - Runtime type checking for all block types

### Project Structure

```
src/
├── components/
│   ├── blocks/              # Block renderers (display & editable)
│   ├── richtext/            # Rich text rendering & editing
│   ├── LinearDocument.tsx   # Main display component
│   └── EditableLinearDocument.tsx  # Main editable component
├── lib/
│   ├── byte-utils.ts        # UTF-8/UTF-16 conversion
│   ├── richtext.ts          # RichText class
│   ├── facets.ts            # Facet manipulation utilities
│   └── type-guards.ts       # Type guard functions
├── types/
│   └── index.ts             # Type re-exports from lex-api
└── lib-exports.ts           # Public API exports
```

## Known Limitations (MVP)

1. **Block Wrapper Skipped**: The lexicon specifies blocks should be wrapped in `{ $type: "..#block", block: <actual block> }`, but for MVP simplicity we treat `blocks` as a direct array of block types. Full lexicon compliance would require updating all components.

2. **No Formatting Toolbar**: Edit mode preserves existing facets during editing but doesn't provide UI to add new formatting. This is intentional for the MVP.

3. **Limited Block Types**: Only the most common block types are implemented. Additional blocks (website embeds, math, polls, etc.) can be added following the existing patterns.

4. **Simple Edit UX**: Uses `contentEditable` for text editing. A production version might use ProseMirror or similar for richer editing capabilities.

## Type Safety Notes

Due to limitations in the auto-generated lex-api types (union types with optional `$type`), some type assertions are necessary:

- `as never` assertions in `EditableBlockRenderer` to handle union type limitations
- `as unknown as LinearDocument` in demo data to bypass wrapper structure mismatch

These are documented with comments explaining why they're needed.

## Attribution

This project references code and schemas from [Leaflet](https://www.leaflet.pub) by Learning Futures Inc., licensed under MIT. See [ATTRIBUTION.md](./ATTRIBUTION.md) for details.

## License

MIT
